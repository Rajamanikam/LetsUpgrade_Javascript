// function ask(question, yes, no) {
//     if (confirm(question)) yes()
//     else no();
// }

// ask(
//     "Do You Agree?",
//     function() {alert ("You Agreed.");},
//     function() {alert ("You Cancelled The Execution.");}
// );

//*****Arrow Function*****

function ask(question, yes, no) {
    if (confirm(question)) yes()
    else no();
  }
  
  ask(
    "Do you agree?",
    () => alert("You agreed."),
    () => alert("You canceled the execution.")
  );