let num;

do {
  num = prompt("Enter a number greater than 100 :");
} while (num <= 100 && num);