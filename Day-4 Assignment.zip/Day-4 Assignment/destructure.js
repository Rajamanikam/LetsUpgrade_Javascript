const student = {
    name: "Helsinki",
    age: 24,
    projects: {
        diceGame: "Two player dice game using JavaScript"
    }
}

const{ name, age, projects:{diceGame}} = student; //object destructuring with multiple values

console.log(name);
console.log(age);
console.log(projects);