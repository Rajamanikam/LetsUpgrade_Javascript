for(let i = 1; i <= 100; i++) 
{
    if (i % 3 == 0 && i % 5 == 0) //divisible by both 3 and 5
    {
        console.log("fizzbuzz");
    } 
    else if (i % 3 == 0) //divisible only by 3
    {
        console.log("fizz");
    }
    else if(i % 5 == 0) //divisible only by 5
    {
        console.log("buzz");
    }
}