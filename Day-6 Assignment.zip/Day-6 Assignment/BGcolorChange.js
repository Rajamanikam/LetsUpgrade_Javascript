var i = 0;
function change() {
  var doc = document.getElementById("background");
  var color = ["red", "blue", "yellow", "green","orange"];
  doc.style.backgroundColor = color[i];
  i = (i + 1) % color.length;
}
setInterval(change, 5000); // changing color every 5 secs
