  
console.log("OOPS Practice in JS");

class User {
    constructor(name, age,email) {
      this.name = name;
      this.age = age;
      this.email = email;
      this.luCoins = 0;
      this.courses = [];
    }

    static greet(){
        console.log("Hello, Welcome to our community");
    }

    login(){
        console.log(`${this.name} has logged in`);
        return this;
    }
    getDetails(){
        console.log(`Name is ${this.name}, email is ${this.email}`);
             return this;
    }
    logout(){
        console.log(`${this.name} has logged out`);
        return this;
    }
}

class Moderator extends User{
    constructor(name,age,email,role){
        super(name,age,email);
        this.role = role;
    }
    addCoins(value){
        this.luCoins += value;
        console.log(`${this.name} has ${this.luCoins} coins`);
        return this;
    }
    removeCoins(value){
        this.luCoins -= value;
        console.log(`${this.name} has ${this.luCoins} coins`);
        return this;
    }
}

class Admin extends Moderator{
   addCourse(user,course){
       user.courses.push(course);
       console.log(user);
   }
   deleteUser(user){
    users = users.filter(u =>{
        return u.email != user.email; 
    })
}
}


let user1 = new User('Raja',21,'raja563@gmail.com')
let user2 = new User('Hari',22,'hari372@gmai.com')
let user3 = new User('Vicky',21,'vicks372@gmai.com')
let mod = new Moderator('Kumar',29,'kumar243@gmail.com','Moderator');
let admin = new Admin('Sarath',36,'Sk262@gmail.com');
let users = [user1,user2,mod,admin];

users.forEach(element => {
    console.log(element);
});


//For User

User.greet();
user1.login();
user1.getDetails();
user1.logout();
User.greet();
user2.login().logout();

//For Moderator

mod.login().addCoins(5).logout();

//For Admin

//user1 courses
admin.addCourse(user1,'Javascript');
admin.addCourse(user1,'Python');

//user2 courses
admin.addCourse(user2,'Javascript');
admin.addCourse(user2,'Blockchain');
admin.addCourse(user2,'Java');

//user3 courses
admin.addCourse(user3,'Javascript');


console.log(users);
admin.deleteUser(user3);

//Final array
console.log(users);