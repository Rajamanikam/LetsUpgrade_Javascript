//Getting input from User

N = prompt("Enter The value of N:");
var myarr = [];

//Creating an array of numbers

for (var i = 1; i <= N; i++) {
   myarr.push(i);
}
console.log(myarr)

//Creating a new array with odd numbers only using filter()

var oddnums = myarr.filter(num => num % 2 !== 0);
console.log(oddnums)

var cubenums = oddnums.map(num => num ** 3);
console.log(cubenums)